//
//  CalculatorViewController.swift
//  Example
//
//  Created by William.Weng on 2024/1/1.
//
// [色卡](https://coolors.co/palettes/trending)
// [CombineCocoa 是基於 Combine 對 UIKit Controls 的封裝](https://juejin.cn/post/6844903910944030727)
// [Combine之Subjects - 知乎](https://zhuanlan.zhihu.com/p/344164793)

import UIKit
import SnapKit
import Combine
import CombineCocoa
import WWPrint

// MARK: - CalculatorViewController
final class CalculatorViewController: UIViewController {

    private let logoView = LogoView()
    private let resultView = ResultInputView()
    private let billInputView = BillInputView()
    private let tipInputView = TipInputView()
    private let splitInputView = SplitInputView()
    private let viewModel = CalculatorViewModel()
    
    private var cancelables: Set<AnyCancellable> = []
    
    private lazy var vStackView: UIStackView = vStackViewMaker()
    private lazy var viewTapPublisher: AnyPublisher<Void, Never> = viewTapPublisherMaker(forView: view)
    private lazy var logoViewTapPublisher: AnyPublisher<Void, Never> = viewTapPublisherMaker(numberOfTapsRequired: 2, forView: logoView)

    override func viewDidLoad() {
        super.viewDidLoad()
        layout()
        bind()
        observe()
    }
}

// MARK: - 小工具
private extension CalculatorViewController {
    
    func layout() {
        
        view.backgroundColor = Constant.ThemeColor.primary.color()
        view.addSubview(vStackView)
        
        vStackView.snp.makeConstraints { make in
            make.leading.equalTo(view.snp.leadingMargin).offset(16)
            make.trailing.equalTo(view.snp.trailingMargin).offset(-16)
            make.bottom.equalTo(view.snp.bottomMargin).offset(-16)
            make.top.equalTo(view.snp.topMargin).offset(16)
        }
        
        logoView.snp.makeConstraints { make in make.height.equalTo(48) }
        resultView.snp.makeConstraints { make in make.height.equalTo(224) }
        billInputView.snp.makeConstraints { make in make.height.equalTo(56) }
        tipInputView.snp.makeConstraints { make in make.height.equalTo(56 + 56 + 15) }
        splitInputView.snp.makeConstraints { make in make.height.equalTo(56) }
    }
    
    func vStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews: [
            logoView,
            resultView,
            billInputView,
            tipInputView,
            splitInputView,
            UIView(),
        ])
        
        stackView.axis = .vertical
        stackView.spacing = 36
        
        return stackView
    }
}

// MARK: - Combine
private extension CalculatorViewController {
    
    /// 綁定變數 (把變數指標傳過去)
    func bind() {
        
        billInputView.valuePublisher.sink { bill in
            wwPrint("bill: \(bill)")
        }.store(in: &cancelables)
        
        let input = CalculatorViewModel.Input(
            billPublisher: billInputView.valuePublisher,    // billPublisher: Just(10).eraseToAnyPublisher(),
            tipPublisher: tipInputView.valuePublisher,      // tipPublisher: Just(.tenPercent).eraseToAnyPublisher(),
            splitPublisher: splitInputView.valuePublisher,  // splitPublisher: Just(5).eraseToAnyPublisher()
            logoViewTapPublisher: logoViewTapPublisher
        )
        
        let output = viewModel.transform(input: input)
        
        output.updateViewPublisher.sink { [unowned self] result in
            resultView.configure(result: result)
            wwPrint("\(result)")
        }.store(in: &cancelables)
        
        output.resetCalcuatorPublisher.sink { [unowned self] _ in
            resetAction()
        }.store(in: &cancelables)
    }
    
    func observe() {
        
        viewTapPublisher.sink { [unowned self] value in
            view.endEditing(true)
        }.store(in: &cancelables)
        
        logoViewTapPublisher.sink { value in
            wwPrint("logoViewTapPublisher")
        }.store(in: &cancelables)
    }
    
    func viewTapPublisherMaker(numberOfTapsRequired: Int = 1, forView view: UIView) -> AnyPublisher<Void, Never> {
        
        let tapGesture = UITapGestureRecognizer(target: self, action: nil)
        tapGesture.numberOfTapsRequired = numberOfTapsRequired
        view.addGestureRecognizer(tapGesture)
        
        return tapGesture.tapPublisher.flatMap { _ in
            Just(())
        }.eraseToAnyPublisher()
    }
    
    func resetAction() {
        
        billInputView.reset()
        tipInputView.reset()
        splitInputView.reset()
        
        UIView.animate(withDuration: 0.2, delay: 0, usingSpringWithDamping: 5.0, initialSpringVelocity: 0.5, options: .curveEaseInOut) { [unowned self] in
            logoView.transform = .init(scaleX: 2.0, y: 2.0)
        } completion: { _ in
            UIView.animate(withDuration: 0.2) { [unowned self] in
                logoView.transform = .identity
            }
        }
    }
}

