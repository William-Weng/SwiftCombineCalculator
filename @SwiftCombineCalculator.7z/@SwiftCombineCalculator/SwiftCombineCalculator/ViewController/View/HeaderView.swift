//
//  HeaderView.swift
//  Example
//
//  Created by iOS on 2024/1/31.
//

import UIKit

final class HeaderView: UIView {
    
    private lazy var topLabel = topLabelMaker()
    private lazy var bottomLabel = bottomLabelMaker()
    private lazy var topSpacerView = UIView()
    private lazy var bottomSpacerView = UIView()
    private lazy var vStackView = vStackViewMaker()
    
    init() {
        super.init(frame: .zero)
        layout()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func configure(topText: String, bottomText: String) {
        topLabel.text = topText
        bottomLabel.text = bottomText
    }
}

private extension HeaderView {
    
    func layout() {
        
        addSubview(vStackView)
        
        vStackView.snp.makeConstraints { make in make.edges.equalToSuperview() }
        topSpacerView.snp.makeConstraints { make in make.height.equalTo(bottomSpacerView) }
    }
    
    func vStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews: [
            topSpacerView,
            topLabel,
            bottomLabel,
            bottomSpacerView,
        ])
        
        stackView.axis = .vertical
        stackView.alignment = .leading
        stackView.spacing = -4
        
        return stackView
    }
    
    func topLabelMaker() -> UILabel {
        let label = Utility.shared.labelMaker(text: nil, font: Constant.ThemeFont.bold.font(ofSize: 18))
        return label
    }
    
    func bottomLabelMaker() -> UILabel {
        let label = Utility.shared.labelMaker(text: nil, font: Constant.ThemeFont.regular.font(ofSize: 16))
        return label
    }
}
