//
//  SplitInputView.swift
//  Example
//
//  Created by iOS on 2024/1/31.
//

import UIKit
import Combine

final class SplitInputView: UIView {
    
    enum InputButtonType: String {
        case increment = "+"
        case decrement = "-"
    }
    
    var valuePublisher: AnyPublisher<Int, Never> { return splitSubject.removeDuplicates().eraseToAnyPublisher() }
    
    private let splitSubject: CurrentValueSubject<Int, Never> = .init(1)
    
    private var cancelables: Set<AnyCancellable> = []
    
    private lazy var headerView = headerViewMaker()
    private lazy var incrementButton = buttonMaker(type: .increment, corners: [.layerMaxXMinYCorner, .layerMaxXMaxYCorner])
    private lazy var decrementButton = buttonMaker(type: .decrement, corners: [.layerMinXMaxYCorner, .layerMinXMinYCorner])
    private lazy var quantityLabel = quantityLabelMaker()
    private lazy var hStackView = hStackViewMaker()
    
    init() {
        super.init(frame: .zero)
        layout()
        observe()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func reset() {
        splitSubject.send(1)
    }
}

private extension SplitInputView {
    
    func layout() {
        
        [headerView, hStackView].forEach(addSubview(_:))
        
        hStackView.snp.makeConstraints { make in make.top.bottom.trailing.equalToSuperview() }
        
        [incrementButton, decrementButton].forEach { button in
            button.snp.makeConstraints { make in make.width.equalTo(button.snp.height) }
        }
        
        headerView.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.centerY.equalTo(hStackView.snp.centerY)
            make.trailing.equalTo(hStackView.snp.leading).offset(-24)
            make.width.equalTo(68)
        }
    }
    
    func headerViewMaker() -> HeaderView {
        
        let headerView = HeaderView()
        headerView.configure(topText: "Split", bottomText: "the total")
        
        return headerView
    }

    func buttonMaker(type: InputButtonType, corners: CACornerMask) -> UIButton {
        
        let button = UIButton()
        
        button.setTitle(type.rawValue, for: .normal)
        button.titleLabel?.font = Constant.ThemeFont.bold.font(ofSize: 20)
        button.layer._maskedCorners(radius: 8, corners: corners)
        button.backgroundColor = Constant.ThemeColor.secondary.color()
        
        button.tapPublisher.flatMap { [unowned self] _ in
            
            var value: Int = splitSubject.value
            
            switch type {
            case .increment: value += 1
            case .decrement: value -= 1
            }
            
            if (value < 1) { value = 1 }
            
            return Just(value)
            
        }.assign(to: \.value, on: splitSubject)
        .store(in: &cancelables)
        
        return button
    }
    
    func observe() {
        
        splitSubject.sink { [unowned self] quantity in
            quantityLabel.text = "\(quantity)"
        }.store(in: &cancelables)
    }
    
    func quantityLabelMaker() -> UILabel {
        let label = Utility.shared.labelMaker(text: "1", font: Constant.ThemeFont.bold.font(ofSize: 20), backgroundColor: .white)
        return label
    }
    
    func hStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews:[
            decrementButton,
            quantityLabel,
            incrementButton,
        ])
        
        stackView.axis = .horizontal
        stackView.spacing = 0
        
        return stackView
    }
}

