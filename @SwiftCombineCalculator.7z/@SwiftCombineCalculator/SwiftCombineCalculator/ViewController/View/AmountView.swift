//
//  AmountView.swift
//  Example
//
//  Created by iOS on 2024/1/31.
//

import UIKit

final class AmountView: UIView {
    
    private let title: String
    private let textAlignment: NSTextAlignment
    
    private lazy var titleLabel = titleLabelMaker()
    private lazy var amountLabel = amountLabelMaker()
    private lazy var vStackView = vStackViewMaker()

    init(title: String, textAlignment: NSTextAlignment) {
    
        self.title = title
        self.textAlignment = textAlignment
        
        super.init(frame: .zero)
        layout()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func configure(amount: Double) {
        
        let attributedText = NSMutableAttributedString(
            string: "\(amount._currencyFormatted())",
            attributes: [.font: Constant.ThemeFont.bold.font(ofSize: 24)])
        
        attributedText.addAttributes([.font: Constant.ThemeFont.bold.font(ofSize: 16)], range: NSMakeRange(0, 1))
        amountLabel.attributedText = attributedText
    }
}

private extension AmountView {
    
    func layout() {
        
        addSubview(vStackView)
        vStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func titleLabelMaker() -> UILabel {
        let label = Utility.shared.labelMaker(text: title, font: Constant.ThemeFont.regular.font(ofSize: 18), textAlignment: textAlignment)
        return label
    }
    
    func amountLabelMaker() -> UILabel {
        
        let label = UILabel()
        let text = NSMutableAttributedString(string: "$0", attributes: [.font: Constant.ThemeFont.bold.font(ofSize: 24)])
        
        text.addAttributes([.font: Constant.ThemeFont.bold.font(ofSize: 16)], range: NSMakeRange(0, 1))
        
        label.textColor = Constant.ThemeColor.text.color()
        label.attributedText = text
        label.textAlignment = textAlignment
        
        return label
    }
    
    func vStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews: [
            titleLabel,
            amountLabel,
        ])
        
        stackView.axis = .vertical
        
        return stackView
    }
}
