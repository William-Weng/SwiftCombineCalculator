//
//  ResultInputView.swift
//  Example
//
//  Created by iOS on 2024/1/31.
//

import UIKit

final class ResultInputView: UIView {
    
    private lazy var headerLabel = headerLabelMaker()
    private lazy var amountPerPersonLabel = amountPerPersonLabelMaker()
    private lazy var horiziotalLineView = horiziotalLineViewMaker()
    private lazy var vStackView = vStackViewMaker()
    private lazy var hStackView = hStackViewMaker()
    private lazy var totalBillView = totalBillViewMaker()
    private lazy var totalTipView = totalTipViewMaker()

    init() {
        super.init(frame: .zero)
        layout()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func configure(result: Model.Result) {
        
        let text = NSMutableAttributedString(
            string: result.amountPerPerson._currencyFormatted(),
            attributes: [.font: Constant.ThemeFont.bold.font(ofSize: 48)])
        
        text.addAttributes([.font: Constant.ThemeFont.bold.font(ofSize: 24)], range: NSMakeRange(0, 1))
        
        amountPerPersonLabel.attributedText = text
        totalBillView.configure(amount: result.totalBill)
        totalTipView.configure(amount: result.totalTip)
    }
}

private extension ResultInputView {
    
    func layout() {
        
        addSubview(vStackView)
        
        vStackView.snp.makeConstraints { make in
            make.top.equalTo(snp.top).offset(24)
            make.bottom.equalTo(snp.bottom).offset(-24)
            make.leading.equalTo(snp.leading).offset(24)
            make.trailing.equalTo(snp.trailing).offset(-24)
        }
        
        horiziotalLineView.snp.makeConstraints { make in
            make.height.equalTo(2)
        }
        
        self._shadow(with: .lightGray, backgroundColor: .white, offset: CGSize(width: 0, height: 13), opacity: 0.5, radius: 12.0, cornerRadius: 12.0)
    }
        
    func headerLabelMaker() -> UILabel {
        let label = Utility.shared.labelMaker(text: "Total p/persion", font: Constant.ThemeFont.demibold.font(ofSize: 18))
        return label
    }
    
    func amountPerPersonLabelMaker() -> UILabel {
        
        let label = UILabel()
        let text = NSMutableAttributedString(string: "$0", attributes: [.font: Constant.ThemeFont.bold.font(ofSize: 48)])
        
        text.addAttributes([.font: Constant.ThemeFont.bold.font(ofSize: 24)], range: NSMakeRange(0, 1))
        label.attributedText = text
        label.textAlignment = .center
        
        return label
    }
    
    func horiziotalLineViewMaker() -> UIView {
        
        let view = UIView()
        view.backgroundColor = Constant.ThemeColor.separator.color()
        
        return view
    }
    
    func vStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews: [
            headerLabel,
            amountPerPersonLabel,
            horiziotalLineView,
            spacerView(height: 0),
            hStackView,
        ])
        
        stackView.axis = .vertical
        stackView.spacing = 8
        
        return stackView
    }
    
    func totalBillViewMaker() -> AmountView {
        return AmountView(title: "Total bill", textAlignment: .left)
    }
    
    func totalTipViewMaker() -> AmountView {
        return AmountView(title: "Total tip", textAlignment: .left)
    }
    
    func hStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews: [
            totalBillView,
            UIView(),
            totalTipView,
        ])
        
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        
        return stackView
    }
    
    func spacerView(height: CGFloat) -> UIView {
        
        let view = UIView()
        view.heightAnchor.constraint(equalToConstant: height).isActive = true
        
        return view
    }
}
