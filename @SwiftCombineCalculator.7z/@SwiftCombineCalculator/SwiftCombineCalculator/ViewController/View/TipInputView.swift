//
//  TipInputView.swift
//  Example
//
//  Created by iOS on 2024/1/31.
//

import UIKit
import Combine
import CombineCocoa
import WWPrint

final class TipInputView: UIView {

    var valuePublisher: AnyPublisher<Constant.Tip, Never> { return tipSubject.eraseToAnyPublisher() }
    
    private let tipSubject = CurrentValueSubject<Constant.Tip, Never>(.none)
    
    private var cancelables: Set<AnyCancellable> = []
    
    private lazy var headerView = headerViewMaker()
    private lazy var tenPercentTipButton = tipButtonMaker(tip: .tenPercent)
    private lazy var fiftenPercentTipButton = tipButtonMaker(tip: .fiftenPercent)
    private lazy var twentyPercentTipButton = tipButtonMaker(tip: .twentyPercent)
    private lazy var customTipButton = customTipButtonMaker()
    private lazy var buttonVStackView = buttonVStackViewMaker()
    private lazy var buttonHStackView = buttonHStackViewMaker()

    init() {
        super.init(frame: .zero)
        layout()
        observe()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func reset() {
        tipSubject.send(.none)
    }
}

private extension TipInputView {
    
    func layout() {
        
        [headerView, buttonVStackView].forEach(addSubview(_:))
        
        buttonVStackView.snp.makeConstraints { make in make.top.bottom.trailing.equalToSuperview() }
        
        headerView.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.trailing.equalTo(buttonVStackView.snp.leading).offset(-24)
            make.width.equalTo(68)
            make.centerY.equalTo(buttonHStackView.snp.centerY)
        }
    }
    
    func headerViewMaker() -> HeaderView {
        
        let headerView = HeaderView()
        headerView.configure(topText: "Choose", bottomText: "your tip")
        
        return headerView
    }

    func tipButtonMaker(tip: Constant.Tip) -> UIButton {
        
        let button = UIButton(type: .custom)
        let text = NSMutableAttributedString(string: tip.stringVaule, attributes: [
            .font: Constant.ThemeFont.demibold.font(ofSize: 20),
            .foregroundColor: UIColor.white
        ])
        
        text.addAttributes([.font: Constant.ThemeFont.demibold.font(ofSize: 20)], range: NSMakeRange(2, 1))
        
        button.backgroundColor = Constant.ThemeColor.secondary.color()
        button.layer._maskedCorners(radius: 8)
        button.setAttributedTitle(text, for: .normal)
        
        button.tapPublisher.flatMap { _ in
            Just(tip)
        }.assign(to: \.value, on: tipSubject)
        .store(in: &cancelables)
        
        return button
    }
    
    func buttonVStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews:[
            buttonHStackView,
            customTipButton,
        ])
        
        stackView.axis = .vertical
        stackView.distribution = .fillEqually
        stackView.spacing = 16
        
        return stackView
    }
    
    func buttonHStackViewMaker() -> UIStackView {
        
        let stackView = UIStackView(arrangedSubviews:[
            tenPercentTipButton,
            fiftenPercentTipButton,
            twentyPercentTipButton,
        ])
        
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 16
        
        return stackView
    }
    
    func customTipButtonMaker() -> UIButton {
        
        let button = UIButton()
        
        button.setTitle("Custom tip", for: .normal)
        button.titleLabel?.font = Constant.ThemeFont.bold.font(ofSize: 20)
        button.backgroundColor = Constant.ThemeColor.secondary.color()
        button.tintColor = .white
        button.layer._maskedCorners(radius: 8.0)
        button.tapPublisher.sink { [weak self] _ in
            self?.handleCustomTipButton()
        }.store(in: &cancelables)
        
        return button
    }
    
    func handleCustomTipButton() {
        
        let alertController = customAlertControllerMaker()
        self._parentViewController()?.present(alertController, animated: true)
    }
    
    func customAlertControllerMaker() -> UIAlertController {
        
        let alertController = UIAlertController(title: "Enter custom tip", message: nil, preferredStyle: .alert)
        
        alertController.addTextField { textFiled in
            textFiled.placeholder = "Make it generous!"
            textFiled.keyboardType = .numberPad
            textFiled.autocapitalizationType = .none
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        let okAction = UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            
            guard let textField = alertController.textFields?.first,
                  let text = textField.text,
                  let value = text._Int()
            else {
                return
            }
            
            self?.tipSubject.send(.custom(value: value))
        }
        
        [okAction, cancelAction].forEach(alertController.addAction(_:))

        return alertController
    }
    
    func observe() {
        
        tipSubject.sink { [unowned self] tip in
            
            resetView()
            
            switch tip {
            case .none: break
            case .tenPercent: tenPercentTipButton.backgroundColor = Constant.ThemeColor.separator.color()
            case .fiftenPercent: fiftenPercentTipButton.backgroundColor = Constant.ThemeColor.separator.color()
            case .twentyPercent: twentyPercentTipButton.backgroundColor = Constant.ThemeColor.separator.color()
            case .custom(let value):
                
                let text = NSMutableAttributedString(
                    string: "$\(value)",
                    attributes: [.font: Constant.ThemeFont.bold.font(ofSize: 20)]
                )
                
                text.addAttributes([.font: Constant.ThemeFont.bold.font(ofSize: 14)], range: NSMakeRange(0, 1))
                
                customTipButton.backgroundColor = Constant.ThemeColor.separator.color()
                customTipButton.setAttributedTitle(text, for: .normal)
            }
        }.store(in: &cancelables)
    }
    
    func resetView() {
        
        [tenPercentTipButton, fiftenPercentTipButton, twentyPercentTipButton, customTipButton].forEach { $0.backgroundColor = Constant.ThemeColor.secondary.color() }
        
        let text = NSAttributedString(
            string: "Custom tip",
            attributes: [.font: Constant.ThemeFont.bold.font(ofSize: 20)]
        )
        
        customTipButton.setAttributedTitle(text, for: .normal)
    }
}
