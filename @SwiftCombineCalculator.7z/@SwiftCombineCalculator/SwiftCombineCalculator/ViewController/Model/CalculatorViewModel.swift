//
//  CalculatorViewModel.swift
//  Example
//
//  Created by iOS on 2024/2/1.
//

import Foundation
import WWPrint
import Combine

final class CalculatorViewModel {
    
    struct Input {
        let billPublisher: AnyPublisher<Double, Never>
        let tipPublisher: AnyPublisher<Constant.Tip, Never>
        let splitPublisher: AnyPublisher<Int, Never>
        let logoViewTapPublisher: AnyPublisher<Void, Never>
    }
    
    struct Output {
        let updateViewPublisher: AnyPublisher<Model.Result, Never>
        let resetCalcuatorPublisher: AnyPublisher<Void, Never>
    }
    
    private let audioPlayerService: AudioPlayerService
    private var cancelables: Set<AnyCancellable> = []
    
    init(audioPlayerService: AudioPlayerService = DefaultAudioPlayer()) {
        self.audioPlayerService = audioPlayerService
    }
    
    func transform(input: Input) -> Output {
        
//        input.billPublisher.sink { bill in
//            wwPrint("bill => \(bill)")
//        }.store(in: &cancelables)
//
//        input.tipPublisher.sink { tip in
//            wwPrint("tip => \(tip)")
//        }.store(in: &cancelables)
//
//        input.splitPublisher.sink { split in
//            wwPrint("split => \(split)")
//        }.store(in: &cancelables)
        
        let updateViewPublisher = Publishers.CombineLatest3(input.billPublisher, input.tipPublisher, input.splitPublisher).flatMap { [unowned self] (bill, tip, split) in
            
            let totalTip = tipAmount(bill: bill, tip: tip)
            let totalBill = bill + totalTip
            let amountPerPerson = totalBill / Double(split)
            let result = Model.Result(amountPerPerson: amountPerPerson, totalBill: totalBill, totalTip: totalTip)

            return Just(result)
            
        }.eraseToAnyPublisher()
        
        // let result = Model.Result(amountPerPerson: 500, totalBill: 1000, totalTip: 50)
        // let output = Output(updateViewPublisher: Just(result).eraseToAnyPublisher())
        
        // let resultCalcuatorPublisher = input.logoViewTapPublisher
        
        let resultCalcuatorPublisher = input.logoViewTapPublisher.handleEvents(receiveOutput: { [unowned self] in
            audioPlayerService.playSound()
        }).flatMap {
            return Just($0)
        }
        
        let output = Output(
            updateViewPublisher: updateViewPublisher,
            resetCalcuatorPublisher: resultCalcuatorPublisher.eraseToAnyPublisher())
        
        return output
    }
    
    func tipAmount(bill: Double, tip: Constant.Tip) -> Double {
        
        switch tip {
        case .none: return 0
        case .tenPercent: return bill * 0.10
        case .fiftenPercent: return bill * 0.15
        case .twentyPercent: return bill * 0.20
        case .custom(let value): return Double(value)
        }
    }
}
