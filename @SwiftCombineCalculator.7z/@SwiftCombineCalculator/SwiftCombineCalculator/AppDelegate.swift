//
//  AppDelegate.swift
//  Example
//
//  Created by William.Weng on 2024/1/1.
//
/// [iOS & Swift - MVVM, Combine, SnapKit, Snapshot/UI/Unit Tests](https://www.udemy.com/course/ios-swift-mvvm-combine-snapkit-snapshot-ui-unit-tests/)

import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }
}

